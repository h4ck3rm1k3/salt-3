package com.dwipal;

import java.util.*;

public class DwSnmpRequest {
  public DwSnmpRequest() {
  }

  public Collection resultlist;
}
