﻿
var PageName = '管理员信息（启用了操作密码）';
var PageId = '6d6ce97c51184577916a2748559eeb37'
var PageUrl = '管理员信息（启用了操作密码）.html'
document.title = '管理员信息（启用了操作密码）';
var PageNotes = 
{
"pageName":"管理员信息（启用了操作密码）",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '22');
  value = value.replace(/\[\[GenMonth\]\]/g, '8');
  value = value.replace(/\[\[GenMonthName\]\]/g, '八月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期三');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u31 = document.getElementById('u31');
gv_vAlignTable['u31'] = 'center';
var u36 = document.getElementById('u36');

var u16 = document.getElementById('u16');

var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'center';
var u28 = document.getElementById('u28');

var u29 = document.getElementById('u29');
gv_vAlignTable['u29'] = 'center';
var u8 = document.getElementById('u8');

var u30 = document.getElementById('u30');

u30.style.cursor = 'pointer';
if (bIE) u30.attachEvent("onclick", Clicku30);
else u30.addEventListener("click", Clicku30, true);
function Clicku30(e)
{
windowEvent = e;


if (true) {

	self.location.href="修改管理员操作密码.html" + GetQuerystring();

}

}

var u21 = document.getElementById('u21');
gv_vAlignTable['u21'] = 'top';
var u6 = document.getElementById('u6');

var u32 = document.getElementById('u32');

u32.style.cursor = 'pointer';
if (bIE) u32.attachEvent("onclick", Clicku32);
else u32.addEventListener("click", Clicku32, true);
function Clicku32(e)
{
windowEvent = e;


if (true) {

	self.location.href="取消管理员操作密码.html" + GetQuerystring();

}

}

var u15 = document.getElementById('u15');
gv_vAlignTable['u15'] = 'center';
var u13 = document.getElementById('u13');
gv_vAlignTable['u13'] = 'center';
var u14 = document.getElementById('u14');

if (bIE) u14.attachEvent("onmouseover", MouseOveru14);
else u14.addEventListener("mouseover", MouseOveru14, true);
function MouseOveru14(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u14',e)) return;
if (true) {

	SetPanelVisibility('u48','','none',500);

}

}

if (bIE) u14.attachEvent("onmouseout", MouseOutu14);
else u14.addEventListener("mouseout", MouseOutu14, true);
function MouseOutu14(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u14',e)) return;
if (true) {

	SetPanelVisibility('u48','hidden','none',500);

}

}

var u4 = document.getElementById('u4');

var u38 = document.getElementById('u38');
gv_vAlignTable['u38'] = 'center';
var u43 = document.getElementById('u43');

u43.style.cursor = 'pointer';
if (bIE) u43.attachEvent("onclick", Clicku43);
else u43.addEventListener("click", Clicku43, true);
function Clicku43(e)
{
windowEvent = e;


if (true) {

	self.location.href="成员管理界面.html" + GetQuerystring();

}

}

if (bIE) u43.attachEvent("onmouseover", MouseOveru43);
else u43.addEventListener("mouseover", MouseOveru43, true);
function MouseOveru43(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u43',e)) return;
if (true) {

	SetPanelVisibility('u42','','none',500);

}

}

if (bIE) u43.attachEvent("onmouseout", MouseOutu43);
else u43.addEventListener("mouseout", MouseOutu43, true);
function MouseOutu43(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u43',e)) return;
if (true) {

	SetPanelVisibility('u42','hidden','none',500);

}

}

var u44 = document.getElementById('u44');
gv_vAlignTable['u44'] = 'center';
var u40 = document.getElementById('u40');

u40.style.cursor = 'pointer';
if (bIE) u40.attachEvent("onclick", Clicku40);
else u40.addEventListener("click", Clicku40, true);
function Clicku40(e)
{
windowEvent = e;


if (true) {

	self.location.href="存储管理页面.html" + GetQuerystring();

}

}

if (bIE) u40.attachEvent("onmouseover", MouseOveru40);
else u40.addEventListener("mouseover", MouseOveru40, true);
function MouseOveru40(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u40',e)) return;
if (true) {

	SetPanelVisibility('u39','','none',500);

}

}

if (bIE) u40.attachEvent("onmouseout", MouseOutu40);
else u40.addEventListener("mouseout", MouseOutu40, true);
function MouseOutu40(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u40',e)) return;
if (true) {

	SetPanelVisibility('u39','hidden','none',500);

}

}

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u37 = document.getElementById('u37');

u37.style.cursor = 'pointer';
if (bIE) u37.attachEvent("onclick", Clicku37);
else u37.addEventListener("click", Clicku37, true);
function Clicku37(e)
{
windowEvent = e;


if (true) {

	self.location.href="企业信息页面.html" + GetQuerystring();

}

}

if (bIE) u37.attachEvent("onmouseover", MouseOveru37);
else u37.addEventListener("mouseover", MouseOveru37, true);
function MouseOveru37(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u37',e)) return;
if (true) {

	SetPanelVisibility('u36','','none',500);

}

}

if (bIE) u37.attachEvent("onmouseout", MouseOutu37);
else u37.addEventListener("mouseout", MouseOutu37, true);
function MouseOutu37(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u37',e)) return;
if (true) {

	SetPanelVisibility('u36','hidden','none',500);

}

}

var u26 = document.getElementById('u26');
gv_vAlignTable['u26'] = 'top';
var u41 = document.getElementById('u41');
gv_vAlignTable['u41'] = 'center';
var u10 = document.getElementById('u10');

var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'center';
var u3 = document.getElementById('u3');
gv_vAlignTable['u3'] = 'center';
var u12 = document.getElementById('u12');

var u39 = document.getElementById('u39');

var u9 = document.getElementById('u9');
gv_vAlignTable['u9'] = 'center';
var u35 = document.getElementById('u35');
gv_vAlignTable['u35'] = 'top';
var u27 = document.getElementById('u27');
gv_vAlignTable['u27'] = 'top';
var u7 = document.getElementById('u7');
gv_vAlignTable['u7'] = 'center';
var u42 = document.getElementById('u42');

var u23 = document.getElementById('u23');
gv_vAlignTable['u23'] = 'top';
var u24 = document.getElementById('u24');
gv_vAlignTable['u24'] = 'top';
var u25 = document.getElementById('u25');
gv_vAlignTable['u25'] = 'top';
var u46 = document.getElementById('u46');

u46.style.cursor = 'pointer';
if (bIE) u46.attachEvent("onclick", Clicku46);
else u46.addEventListener("click", Clicku46, true);
function Clicku46(e)
{
windowEvent = e;


if (true) {

	self.location.href="共享管理界面.html" + GetQuerystring();

}

}

if (bIE) u46.attachEvent("onmouseover", MouseOveru46);
else u46.addEventListener("mouseover", MouseOveru46, true);
function MouseOveru46(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u46',e)) return;
if (true) {

	SetPanelVisibility('u45','','none',500);

}

}

if (bIE) u46.attachEvent("onmouseout", MouseOutu46);
else u46.addEventListener("mouseout", MouseOutu46, true);
function MouseOutu46(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u46',e)) return;
if (true) {

	SetPanelVisibility('u45','hidden','none',500);

}

}

var u2 = document.getElementById('u2');

var u18 = document.getElementById('u18');

var u19 = document.getElementById('u19');
gv_vAlignTable['u19'] = 'center';
var u20 = document.getElementById('u20');
gv_vAlignTable['u20'] = 'top';
var u5 = document.getElementById('u5');
gv_vAlignTable['u5'] = 'center';
var u48 = document.getElementById('u48');

var u22 = document.getElementById('u22');
gv_vAlignTable['u22'] = 'top';
var u49 = document.getElementById('u49');

u49.style.cursor = 'pointer';
if (bIE) u49.attachEvent("onclick", Clicku49);
else u49.addEventListener("click", Clicku49, true);
function Clicku49(e)
{
windowEvent = e;


if (true) {

	self.location.href="操作历史.html" + GetQuerystring();

}

}

if (bIE) u49.attachEvent("onmouseover", MouseOveru49);
else u49.addEventListener("mouseover", MouseOveru49, true);
function MouseOveru49(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u49',e)) return;
if (true) {

	SetPanelVisibility('u48','','none',500);

}

}

if (bIE) u49.attachEvent("onmouseout", MouseOutu49);
else u49.addEventListener("mouseout", MouseOutu49, true);
function MouseOutu49(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u49',e)) return;
if (true) {

	SetPanelVisibility('u48','hidden','none',500);

}

}

var u47 = document.getElementById('u47');
gv_vAlignTable['u47'] = 'center';
var u50 = document.getElementById('u50');
gv_vAlignTable['u50'] = 'center';
var u51 = document.getElementById('u51');

u51.style.cursor = 'pointer';
if (bIE) u51.attachEvent("onclick", Clicku51);
else u51.addEventListener("click", Clicku51, true);
function Clicku51(e)
{
windowEvent = e;


if (true) {

	self.location.href="企业信息页面.html" + GetQuerystring();

}

}

var u45 = document.getElementById('u45');

var u52 = document.getElementById('u52');
gv_vAlignTable['u52'] = 'center';
var u33 = document.getElementById('u33');
gv_vAlignTable['u33'] = 'center';
var u34 = document.getElementById('u34');
gv_vAlignTable['u34'] = 'top';
var u0 = document.getElementById('u0');

if (window.OnLoad) OnLoad();
