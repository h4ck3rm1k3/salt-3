﻿
var PageName = '企业信息页面';
var PageId = 'cf1123d0722b47dcb6b10c0319f0e11a'
var PageUrl = '企业信息页面.html'
document.title = '企业信息页面';
var PageNotes = 
{
"pageName":"企业信息页面",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '22');
  value = value.replace(/\[\[GenMonth\]\]/g, '8');
  value = value.replace(/\[\[GenMonthName\]\]/g, '八月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期三');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u31 = document.getElementById('u31');
gv_vAlignTable['u31'] = 'center';
var u36 = document.getElementById('u36');

u36.style.cursor = 'pointer';
if (bIE) u36.attachEvent("onclick", Clicku36);
else u36.addEventListener("click", Clicku36, true);
function Clicku36(e)
{
windowEvent = e;


if (true) {

	self.location.href="共享管理界面.html" + GetQuerystring();

}

}

if (bIE) u36.attachEvent("onmouseover", MouseOveru36);
else u36.addEventListener("mouseover", MouseOveru36, true);
function MouseOveru36(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u36',e)) return;
if (true) {

	SetPanelVisibility('u35','','none',500);

}

}

if (bIE) u36.attachEvent("onmouseout", MouseOutu36);
else u36.addEventListener("mouseout", MouseOutu36, true);
function MouseOutu36(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u36',e)) return;
if (true) {

	SetPanelVisibility('u35','hidden','none',500);

}

}

var u16 = document.getElementById('u16');

if (bIE) u16.attachEvent("onmouseover", MouseOveru16);
else u16.addEventListener("mouseover", MouseOveru16, true);
function MouseOveru16(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u16',e)) return;
if (true) {

	SetPanelVisibility('u41','','none',500);

}

}

if (bIE) u16.attachEvent("onmouseout", MouseOutu16);
else u16.addEventListener("mouseout", MouseOutu16, true);
function MouseOutu16(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u16',e)) return;
if (true) {

	SetPanelVisibility('u41','hidden','none',500);

}

}

var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'center';
var u28 = document.getElementById('u28');

u28.style.cursor = 'pointer';
if (bIE) u28.attachEvent("onclick", Clicku28);
else u28.addEventListener("click", Clicku28, true);
function Clicku28(e)
{
windowEvent = e;


if (true) {

	self.location.href="企业联系地址.html" + GetQuerystring();

}

}
gv_vAlignTable['u28'] = 'top';
var u29 = document.getElementById('u29');

var u8 = document.getElementById('u8');

if (bIE) u8.attachEvent("onmouseover", MouseOveru8);
else u8.addEventListener("mouseover", MouseOveru8, true);
function MouseOveru8(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u8',e)) return;
if (true) {

	SetPanelVisibility('u29','','none',500);

}

}

if (bIE) u8.attachEvent("onmouseout", MouseOutu8);
else u8.addEventListener("mouseout", MouseOutu8, true);
function MouseOutu8(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u8',e)) return;
if (true) {

	SetPanelVisibility('u29','hidden','none',500);

}

}

var u30 = document.getElementById('u30');

u30.style.cursor = 'pointer';
if (bIE) u30.attachEvent("onclick", Clicku30);
else u30.addEventListener("click", Clicku30, true);
function Clicku30(e)
{
windowEvent = e;


if (true) {

	self.location.href="存储管理页面.html" + GetQuerystring();

}

}

if (bIE) u30.attachEvent("onmouseover", MouseOveru30);
else u30.addEventListener("mouseover", MouseOveru30, true);
function MouseOveru30(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u30',e)) return;
if (true) {

	SetPanelVisibility('u29','','none',500);

}

}

if (bIE) u30.attachEvent("onmouseout", MouseOutu30);
else u30.addEventListener("mouseout", MouseOutu30, true);
function MouseOutu30(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u30',e)) return;
if (true) {

	SetPanelVisibility('u29','hidden','none',500);

}

}

var u21 = document.getElementById('u21');
gv_vAlignTable['u21'] = 'top';
var u6 = document.getElementById('u6');

var u32 = document.getElementById('u32');

var u15 = document.getElementById('u15');
gv_vAlignTable['u15'] = 'center';
var u13 = document.getElementById('u13');
gv_vAlignTable['u13'] = 'center';
var u14 = document.getElementById('u14');

if (bIE) u14.attachEvent("onmouseover", MouseOveru14);
else u14.addEventListener("mouseover", MouseOveru14, true);
function MouseOveru14(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u14',e)) return;
if (true) {

	SetPanelVisibility('u38','','none',500);

}

}

if (bIE) u14.attachEvent("onmouseout", MouseOutu14);
else u14.addEventListener("mouseout", MouseOutu14, true);
function MouseOutu14(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u14',e)) return;
if (true) {

	SetPanelVisibility('u38','hidden','none',500);

}

}

var u4 = document.getElementById('u4');

var u38 = document.getElementById('u38');

var u43 = document.getElementById('u43');
gv_vAlignTable['u43'] = 'center';
var u40 = document.getElementById('u40');
gv_vAlignTable['u40'] = 'center';
var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u37 = document.getElementById('u37');
gv_vAlignTable['u37'] = 'center';
var u26 = document.getElementById('u26');
gv_vAlignTable['u26'] = 'top';
var u41 = document.getElementById('u41');

var u10 = document.getElementById('u10');

if (bIE) u10.attachEvent("onmouseover", MouseOveru10);
else u10.addEventListener("mouseover", MouseOveru10, true);
function MouseOveru10(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u10',e)) return;
if (true) {

	SetPanelVisibility('u32','','none',500);

}

}

if (bIE) u10.attachEvent("onmouseout", MouseOutu10);
else u10.addEventListener("mouseout", MouseOutu10, true);
function MouseOutu10(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u10',e)) return;
if (true) {

	SetPanelVisibility('u32','hidden','none',500);

}

}

var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'center';
var u3 = document.getElementById('u3');
gv_vAlignTable['u3'] = 'center';
var u12 = document.getElementById('u12');

if (bIE) u12.attachEvent("onmouseover", MouseOveru12);
else u12.addEventListener("mouseover", MouseOveru12, true);
function MouseOveru12(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u12',e)) return;
if (true) {

	SetPanelVisibility('u35','','none',500);

}

}

if (bIE) u12.attachEvent("onmouseout", MouseOutu12);
else u12.addEventListener("mouseout", MouseOutu12, true);
function MouseOutu12(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u12',e)) return;
if (true) {

	SetPanelVisibility('u35','hidden','none',500);

}

}

var u39 = document.getElementById('u39');

u39.style.cursor = 'pointer';
if (bIE) u39.attachEvent("onclick", Clicku39);
else u39.addEventListener("click", Clicku39, true);
function Clicku39(e)
{
windowEvent = e;


if (true) {

	self.location.href="存储管理页面.html" + GetQuerystring();

}

}

if (bIE) u39.attachEvent("onmouseover", MouseOveru39);
else u39.addEventListener("mouseover", MouseOveru39, true);
function MouseOveru39(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u39',e)) return;
if (true) {

	SetPanelVisibility('u38','','none',500);

}

}

if (bIE) u39.attachEvent("onmouseout", MouseOutu39);
else u39.addEventListener("mouseout", MouseOutu39, true);
function MouseOutu39(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u39',e)) return;
if (true) {

	SetPanelVisibility('u38','hidden','none',500);

}

}

var u9 = document.getElementById('u9');
gv_vAlignTable['u9'] = 'center';
var u35 = document.getElementById('u35');

var u27 = document.getElementById('u27');
gv_vAlignTable['u27'] = 'top';
var u7 = document.getElementById('u7');
gv_vAlignTable['u7'] = 'center';
var u42 = document.getElementById('u42');

u42.style.cursor = 'pointer';
if (bIE) u42.attachEvent("onclick", Clicku42);
else u42.addEventListener("click", Clicku42, true);
function Clicku42(e)
{
windowEvent = e;


if (true) {

	self.location.href="管理员信息（未启用操作密码）.html" + GetQuerystring();

}

}

if (bIE) u42.attachEvent("onmouseover", MouseOveru42);
else u42.addEventListener("mouseover", MouseOveru42, true);
function MouseOveru42(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u42',e)) return;
if (true) {

	SetPanelVisibility('u41','','none',500);

}

}

if (bIE) u42.attachEvent("onmouseout", MouseOutu42);
else u42.addEventListener("mouseout", MouseOutu42, true);
function MouseOutu42(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u42',e)) return;
if (true) {

	SetPanelVisibility('u41','hidden','none',500);

}

}

var u23 = document.getElementById('u23');

u23.style.cursor = 'pointer';
if (bIE) u23.attachEvent("onclick", Clicku23);
else u23.addEventListener("click", Clicku23, true);
function Clicku23(e)
{
windowEvent = e;


if (true) {

	self.location.href="编辑名称.html" + GetQuerystring();

}

}
gv_vAlignTable['u23'] = 'top';
var u24 = document.getElementById('u24');
gv_vAlignTable['u24'] = 'top';
var u25 = document.getElementById('u25');

u25.style.cursor = 'pointer';
if (bIE) u25.attachEvent("onclick", Clicku25);
else u25.addEventListener("click", Clicku25, true);
function Clicku25(e)
{
windowEvent = e;


if (true) {

	self.location.href="电子邮件.html" + GetQuerystring();

}

}
gv_vAlignTable['u25'] = 'top';
var u2 = document.getElementById('u2');

var u18 = document.getElementById('u18');

var u19 = document.getElementById('u19');
gv_vAlignTable['u19'] = 'center';
var u20 = document.getElementById('u20');
gv_vAlignTable['u20'] = 'top';
var u5 = document.getElementById('u5');
gv_vAlignTable['u5'] = 'center';
var u22 = document.getElementById('u22');
gv_vAlignTable['u22'] = 'top';
var u33 = document.getElementById('u33');

u33.style.cursor = 'pointer';
if (bIE) u33.attachEvent("onclick", Clicku33);
else u33.addEventListener("click", Clicku33, true);
function Clicku33(e)
{
windowEvent = e;


if (true) {

	self.location.href="成员管理界面.html" + GetQuerystring();

}

}

if (bIE) u33.attachEvent("onmouseover", MouseOveru33);
else u33.addEventListener("mouseover", MouseOveru33, true);
function MouseOveru33(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u33',e)) return;
if (true) {

	SetPanelVisibility('u32','','none',500);

}

}

if (bIE) u33.attachEvent("onmouseout", MouseOutu33);
else u33.addEventListener("mouseout", MouseOutu33, true);
function MouseOutu33(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u33',e)) return;
if (true) {

	SetPanelVisibility('u32','hidden','none',500);

}

}

var u34 = document.getElementById('u34');
gv_vAlignTable['u34'] = 'center';
var u0 = document.getElementById('u0');

if (window.OnLoad) OnLoad();
