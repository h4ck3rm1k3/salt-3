﻿
var PageName = '操作历史';
var PageId = '9695e446ef2349e7b6509232d29174c2'
var PageUrl = '操作历史.html'
document.title = '操作历史';
var PageNotes = 
{
"pageName":"操作历史",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '22');
  value = value.replace(/\[\[GenMonth\]\]/g, '8');
  value = value.replace(/\[\[GenMonthName\]\]/g, '八月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期三');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u21 = document.getElementById('u21');
gv_vAlignTable['u21'] = 'top';
var u51 = document.getElementById('u51');
gv_vAlignTable['u51'] = 'top';
var u25 = document.getElementById('u25');

var u16 = document.getElementById('u16');

if (bIE) u16.attachEvent("onmouseover", MouseOveru16);
else u16.addEventListener("mouseover", MouseOveru16, true);
function MouseOveru16(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u16',e)) return;
if (true) {

	SetPanelVisibility('u65','','none',500);

}

}

if (bIE) u16.attachEvent("onmouseout", MouseOutu16);
else u16.addEventListener("mouseout", MouseOutu16, true);
function MouseOutu16(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u16',e)) return;
if (true) {

	SetPanelVisibility('u65','hidden','none',500);

}

}

var u55 = document.getElementById('u55');
gv_vAlignTable['u55'] = 'center';
var u46 = document.getElementById('u46');
gv_vAlignTable['u46'] = 'top';
var u31 = document.getElementById('u31');

u31.style.cursor = 'pointer';
if (bIE) u31.attachEvent("onclick", Clicku31);
else u31.addEventListener("click", Clicku31, true);
function Clicku31(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u35','','none',500);

}

}

var u38 = document.getElementById('u38');
gv_vAlignTable['u38'] = 'top';
var u32 = document.getElementById('u32');
gv_vAlignTable['u32'] = 'center';
var u23 = document.getElementById('u23');

var u62 = document.getElementById('u62');

var u53 = document.getElementById('u53');

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u27 = document.getElementById('u27');

var u7 = document.getElementById('u7');
gv_vAlignTable['u7'] = 'center';
var u66 = document.getElementById('u66');

u66.style.cursor = 'pointer';
if (bIE) u66.attachEvent("onclick", Clicku66);
else u66.addEventListener("click", Clicku66, true);
function Clicku66(e)
{
windowEvent = e;


if (true) {

	self.location.href="管理员信息（未启用操作密码）.html" + GetQuerystring();

}

}

if (bIE) u66.attachEvent("onmouseover", MouseOveru66);
else u66.addEventListener("mouseover", MouseOveru66, true);
function MouseOveru66(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u66',e)) return;
if (true) {

	SetPanelVisibility('u65','','none',500);

}

}

if (bIE) u66.attachEvent("onmouseout", MouseOutu66);
else u66.addEventListener("mouseout", MouseOutu66, true);
function MouseOutu66(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u66',e)) return;
if (true) {

	SetPanelVisibility('u65','hidden','none',500);

}

}

var u30 = document.getElementById('u30');
gv_vAlignTable['u30'] = 'top';
var u8 = document.getElementById('u8');

if (bIE) u8.attachEvent("onmouseover", MouseOveru8);
else u8.addEventListener("mouseover", MouseOveru8, true);
function MouseOveru8(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u8',e)) return;
if (true) {

	SetPanelVisibility('u56','','none',500);

}

}

if (bIE) u8.attachEvent("onmouseout", MouseOutu8);
else u8.addEventListener("mouseout", MouseOutu8, true);
function MouseOutu8(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u8',e)) return;
if (true) {

	SetPanelVisibility('u56','hidden','none',500);

}

}

var u60 = document.getElementById('u60');

u60.style.cursor = 'pointer';
if (bIE) u60.attachEvent("onclick", Clicku60);
else u60.addEventListener("click", Clicku60, true);
function Clicku60(e)
{
windowEvent = e;


if (true) {

	self.location.href="成员管理界面.html" + GetQuerystring();

}

}

if (bIE) u60.attachEvent("onmouseover", MouseOveru60);
else u60.addEventListener("mouseover", MouseOveru60, true);
function MouseOveru60(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u60',e)) return;
if (true) {

	SetPanelVisibility('u59','','none',500);

}

}

if (bIE) u60.attachEvent("onmouseout", MouseOutu60);
else u60.addEventListener("mouseout", MouseOutu60, true);
function MouseOutu60(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u60',e)) return;
if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}

}

var u34 = document.getElementById('u34');
gv_vAlignTable['u34'] = 'center';
var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'center';
var u64 = document.getElementById('u64');
gv_vAlignTable['u64'] = 'center';
var u19 = document.getElementById('u19');
gv_vAlignTable['u19'] = 'center';
var u49 = document.getElementById('u49');
gv_vAlignTable['u49'] = 'top';
var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'center';
var u41 = document.getElementById('u41');

var u15 = document.getElementById('u15');
gv_vAlignTable['u15'] = 'center';
var u45 = document.getElementById('u45');

var u36 = document.getElementById('u36');

var u58 = document.getElementById('u58');
gv_vAlignTable['u58'] = 'center';
var u37 = document.getElementById('u37');

var u2 = document.getElementById('u2');

var u22 = document.getElementById('u22');
gv_vAlignTable['u22'] = 'top';
var u13 = document.getElementById('u13');
gv_vAlignTable['u13'] = 'center';
var u52 = document.getElementById('u52');
gv_vAlignTable['u52'] = 'top';
var u43 = document.getElementById('u43');

var u0 = document.getElementById('u0');

var u3 = document.getElementById('u3');
gv_vAlignTable['u3'] = 'center';
var u47 = document.getElementById('u47');

var u68 = document.getElementById('u68');

u68.style.cursor = 'pointer';
if (bIE) u68.attachEvent("onclick", Clicku68);
else u68.addEventListener("click", Clicku68, true);
function Clicku68(e)
{
windowEvent = e;


if (true) {

	self.location.href="企业信息页面.html" + GetQuerystring();

}

}

var u20 = document.getElementById('u20');
gv_vAlignTable['u20'] = 'top';
var u50 = document.getElementById('u50');
gv_vAlignTable['u50'] = 'top';
var u28 = document.getElementById('u28');

var u24 = document.getElementById('u24');

var u54 = document.getElementById('u54');

u54.style.cursor = 'pointer';
if (bIE) u54.attachEvent("onclick", Clicku54);
else u54.addEventListener("click", Clicku54, true);
function Clicku54(e)
{
windowEvent = e;


if (true) {

	self.location.href="企业信息页面.html" + GetQuerystring();

}

}

if (bIE) u54.attachEvent("onmouseover", MouseOveru54);
else u54.addEventListener("mouseover", MouseOveru54, true);
function MouseOveru54(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u54',e)) return;
if (true) {

	SetPanelVisibility('u53','','none',500);

}

}

if (bIE) u54.attachEvent("onmouseout", MouseOutu54);
else u54.addEventListener("mouseout", MouseOutu54, true);
function MouseOutu54(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u54',e)) return;
if (true) {

	SetPanelVisibility('u53','hidden','none',500);

}

}

var u39 = document.getElementById('u39');

var u69 = document.getElementById('u69');
gv_vAlignTable['u69'] = 'center';
var u4 = document.getElementById('u4');

var u6 = document.getElementById('u6');

if (bIE) u6.attachEvent("onmouseover", MouseOveru6);
else u6.addEventListener("mouseover", MouseOveru6, true);
function MouseOveru6(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u6',e)) return;
if (true) {

	SetPanelVisibility('u53','','none',500);

}

}

if (bIE) u6.attachEvent("onmouseout", MouseOutu6);
else u6.addEventListener("mouseout", MouseOutu6, true);
function MouseOutu6(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u6',e)) return;
if (true) {

	SetPanelVisibility('u53','hidden','none',500);

}

}

var u61 = document.getElementById('u61');
gv_vAlignTable['u61'] = 'center';
var u35 = document.getElementById('u35');

var u26 = document.getElementById('u26');

var u65 = document.getElementById('u65');

var u56 = document.getElementById('u56');

var u5 = document.getElementById('u5');
gv_vAlignTable['u5'] = 'center';
var u12 = document.getElementById('u12');

if (bIE) u12.attachEvent("onmouseover", MouseOveru12);
else u12.addEventListener("mouseover", MouseOveru12, true);
function MouseOveru12(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u12',e)) return;
if (true) {

	SetPanelVisibility('u62','','none',500);

}

}

if (bIE) u12.attachEvent("onmouseout", MouseOutu12);
else u12.addEventListener("mouseout", MouseOutu12, true);
function MouseOutu12(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u12',e)) return;
if (true) {

	SetPanelVisibility('u62','hidden','none',500);

}

}

var u9 = document.getElementById('u9');
gv_vAlignTable['u9'] = 'center';
var u42 = document.getElementById('u42');
gv_vAlignTable['u42'] = 'top';
var u33 = document.getElementById('u33');

u33.style.cursor = 'pointer';
if (bIE) u33.attachEvent("onclick", Clicku33);
else u33.addEventListener("click", Clicku33, true);
function Clicku33(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u35','hidden','none',500);

}

}

var u63 = document.getElementById('u63');

u63.style.cursor = 'pointer';
if (bIE) u63.attachEvent("onclick", Clicku63);
else u63.addEventListener("click", Clicku63, true);
function Clicku63(e)
{
windowEvent = e;


if (true) {

	self.location.href="共享管理界面.html" + GetQuerystring();

}

}

if (bIE) u63.attachEvent("onmouseover", MouseOveru63);
else u63.addEventListener("mouseover", MouseOveru63, true);
function MouseOveru63(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u63',e)) return;
if (true) {

	SetPanelVisibility('u62','','none',500);

}

}

if (bIE) u63.attachEvent("onmouseout", MouseOutu63);
else u63.addEventListener("mouseout", MouseOutu63, true);
function MouseOutu63(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u63',e)) return;
if (true) {

	SetPanelVisibility('u62','hidden','none',500);

}

}

var u18 = document.getElementById('u18');

var u48 = document.getElementById('u48');
gv_vAlignTable['u48'] = 'top';
var u67 = document.getElementById('u67');
gv_vAlignTable['u67'] = 'center';
var u57 = document.getElementById('u57');

u57.style.cursor = 'pointer';
if (bIE) u57.attachEvent("onclick", Clicku57);
else u57.addEventListener("click", Clicku57, true);
function Clicku57(e)
{
windowEvent = e;


if (true) {

	self.location.href="存储管理页面.html" + GetQuerystring();

}

}

if (bIE) u57.attachEvent("onmouseover", MouseOveru57);
else u57.addEventListener("mouseover", MouseOveru57, true);
function MouseOveru57(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u57',e)) return;
if (true) {

	SetPanelVisibility('u56','','none',500);

}

}

if (bIE) u57.attachEvent("onmouseout", MouseOutu57);
else u57.addEventListener("mouseout", MouseOutu57, true);
function MouseOutu57(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u57',e)) return;
if (true) {

	SetPanelVisibility('u56','hidden','none',500);

}

}

var u10 = document.getElementById('u10');

if (bIE) u10.attachEvent("onmouseover", MouseOveru10);
else u10.addEventListener("mouseover", MouseOveru10, true);
function MouseOveru10(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u10',e)) return;
if (true) {

	SetPanelVisibility('u59','','none',500);

}

}

if (bIE) u10.attachEvent("onmouseout", MouseOutu10);
else u10.addEventListener("mouseout", MouseOutu10, true);
function MouseOutu10(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u10',e)) return;
if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}

}

var u40 = document.getElementById('u40');
gv_vAlignTable['u40'] = 'top';
var u14 = document.getElementById('u14');

var u44 = document.getElementById('u44');
gv_vAlignTable['u44'] = 'top';
var u29 = document.getElementById('u29');
gv_vAlignTable['u29'] = 'top';
var u59 = document.getElementById('u59');

if (window.OnLoad) OnLoad();
